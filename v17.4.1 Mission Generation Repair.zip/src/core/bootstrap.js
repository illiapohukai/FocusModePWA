/**
 * Physical module: src/core/bootstrap.js
 */

if(localStorage.getItem('focus-mode-language')==='ru')localStorage.setItem('focus-mode-language','de');

const I18N={en:{"Intro": "Intro", "Problem": "Problem", "Loesung": "Solution", "Workflow": "How it works", "Kernfunktion": "Core feature", "Motivation": "Motivation", "Überblick": "Overview", "Live testen": "Live demo", "01 / INTRO": "01 / INTRO", "Trainiere deine Aufmerksamkeit. Nicht deine Ablenkung.": "Train your attention. Not your distraction.", "Ein interaktives Konzept für nachhaltige Konzentration, digitale Selbstkontrolle und messbaren Fortschritt.": "An interactive concept for sustainable focus, digital self-control, and measurable progress.", "Konzept entdecken": "Explore the concept", "Prototyp testen": "Test the prototype", "Kapitel": "Chapters", "Prototyp": "Prototype", "Mission": "Mission", "02 / PROBLEM": "02 / PROBLEM", "Dein Smartphone gewinnt zu oft.": "Your smartphone wins too often.", "Der Wechsel von Arbeit zu Ablenkung dauert nur Sekunden. Focus Mode+ macht diesen Moment sichtbar und setzt genau dort eine bewusste Barriere.": "It takes only seconds to switch from work to distraction. Focus Mode+ makes that moment visible and places a conscious barrier exactly where it matters.", "2 Sekunden": "2 seconds", "bis zur nächsten Ablenkung": "until the next distraction", "Kein Widerstand": "No resistance", "zwischen Fokus und Feed": "between focus and the feed", "03 / LOESUNG": "03 / SOLUTION", "Willenskraft wird zum System.": "Willpower becomes a system.", "Fokus-Sitzungen, Verhaltensdaten und adaptive Hürden werden zu einem persönlichen Training für Aufmerksamkeit.": "Focus sessions, behavioral data, and adaptive barriers become personal training for your attention.", "Adaptive Sitzungen": "Adaptive sessions", "Digitale Barrieren": "Digital barriers", "Messbarer Fortschritt": "Measurable progress", "04 / WORKFLOW": "04 / HOW IT WORKS", "Starten. Erkennen. Dranbleiben.": "Start. Recognize. Stay focused.", "Eine Sitzung beginnt bewusst, kritische Wechsel werden erkannt und jede fokussierte Minute fließt in deinen Fortschritt ein.": "Every session starts intentionally, critical switches are detected, and every focused minute contributes to your progress.", "Sitzung starten": "Start a session", "Ablenkung erkennen": "Detect distraction", "Fortschritt sichern": "Save progress", "05 / KERNFUNKTION": "05 / CORE FEATURE", "Die Pause vor der Ablenkung.": "The pause before distraction.", "Eine klare Entscheidungsebene unterbricht den Automatismus, ohne aggressives Lock-in.": "A clear decision layer interrupts the automatic impulse without aggressive lock-in.", "Barriere anzeigen ↗": "Show the barrier ↗", "06 / MOTIVATION": "06 / MOTIVATION", "Fortschritt, den du sehen kannst.": "Progress you can see.", "Focus Score, Streaks, Erfolge und Ranglisten übersetzen Konzentration in verständliche Signale.": "Focus Score, streaks, achievements, and leaderboards turn concentration into clear signals.", "Tage Streak": "day streak", "Fokuszeit": "Focus time", "07 / PREMIUM": "07 / PREMIUM", "Leistung kann Premium freischalten.": "Performance can unlock Premium.", "Premium ist als Abo verfügbar, kann aber auch durch echte Fokuszeit verdient werden.": "Premium is available as a subscription, but it can also be earned through real focus time.", "/ Monat": "/ month", "Oder durch aktive Fokuszeit freischalten.": "Or unlock it through active focus time.", "08 / AI COACH": "08 / AI COACH", "Aus Daten werden Empfehlungen.": "Data becomes guidance.", "Der AI Coach erkennt Muster und formuliert konkrete Vorschläge für bessere Routinen.": "The AI Coach identifies patterns and turns them into practical recommendations for better routines.", "AI Coach öffnen ↗": "Open AI Coach ↗", "09 / VISION": "09 / VISION", "Ein Fokus-System über alle Geräte.": "One focus system across every device.", "Der nächste Schritt ist eine nahtlose Verbindung zwischen Smartphone, Mac und PC.": "The next step is a seamless connection across smartphone, Mac, and PC.", "App selbst testen": "Try the app", "Nach oben": "Back to top", "Willkommen bei": "Welcome to", "Heute gesammelt": "Collected today", "Minuten": "minutes", "Status": "Status", "Bereit": "Ready", "BEREIT": "READY", "Fokus-Serie": "Focus streak", "Diese Woche": "This week", "Verhaltens-Schutz aktiv": "Behavior protection active", "Digitale Barrieren greifen sofort": "Digital barriers activate instantly", "Fokus starten": "Start focus", "Lernmodus": "Study mode", "Fokus aktiv": "Focus active", "Sitzungsdauer": "Session duration", "Intensität": "Intensity", "Mittel": "Medium", "App-Blockierung": "App blocking", "Aktiviert": "Enabled", "Ablenkung": "Distraction", "Beenden": "End session", "Fortschritt": "Progress", "Täglicher Fokus": "Daily focus", "Wochenübersicht": "Weekly overview", "Soll: 60 min/Tag": "Goal: 60 min/day", "Ablenkungen": "Distractions", "1 blockiert": "1 blocked", "Rangliste & Erfolge": "Leaderboard & achievements", "Zurück zum Home": "Back to Home", "Serie": "Streak", "Tage": "days", "Top Fokus-User": "Top focus users", "👤 Du": "👤 You", "Erfolge": "Achievements", "Erste Stunde": "First hour", "60 Min. erreicht": "60 min reached", "Fokus Starter": "Focus starter", "5 Tage aktiv": "5 active days", "Meister": "Master", "100h Fokus": "100h focus", "Unaufhaltsam": "Unstoppable", "30 Tage Streak": "30-day streak", "Konfiguration": "Configuration", "Einstellungen": "Settings", "Fokus-Intensität": "Focus intensity", "Premium aktivieren": "Activate Premium", "Schalte alle Pro-Features & AI-Analysen frei.": "Unlock all Pro features and AI insights.", "Zurück": "Back", "Das Upgrade für deine Aufmerksamkeit": "The upgrade for your attention", "Detaillierte Langzeitstatistiken": "Detailed long-term statistics", "Verhaltensanalyse auf Basis künstlicher Intelligenz": "AI-powered behavioral analysis", "Erweiterte Blockierungs-Modi": "Advanced blocking modes", "Premium abonnieren": "Subscribe to Premium", "Oder kostenlos": "Or for free", "Premium durch Leistung freischalten": "Unlock Premium through performance", "1 Tag Premium": "1 day of Premium", "Für 100 Min. Fokuszeit": "For 100 min of focus time", "Einlösen": "Redeem", "3 Tage Premium": "3 days of Premium", "Benötigt 10h Fokuszeit": "Requires 10h focus time", "7 Tage Premium": "7 days of Premium", "Benötigt 50h Fokuszeit": "Requires 50h focus time", "Zurück zum Dashboard": "Back to dashboard", "Hallo! Ich bin dein AI Coach. Ich scanne, überprüfe und analysiere deine Fokus-Muster, um dir das beste Verhaltenstraining zu bieten.": "Hi! I am your AI Coach. I analyze your focus patterns to provide the most effective attention training.", "Premium erforderlich": "Premium required", "Um diese personalisierte Analyse-Funktion zu nutzen, aktiviere bitte dein Premium-Abonnement.": "Activate Premium to use this personalized analysis feature.", "Zu Premium wechseln": "Go to Premium", "Willkommen im Premium-Modus! Ich habe deine bisherigen Sitzungen analysiert. Wie kann ich dir heute helfen?": "Welcome to Premium! I have analyzed your previous sessions. How can I help you today?", "Was kannst du mir empfehlen?": "What would you recommend?", "Ablenkung erkannt": "Distraction detected", "Möchtest du wirklich die Fokus-Sitzung verlassen und deinen Streak verlieren?": "Do you really want to leave the focus session and lose your streak?", "Zurück zum Fokus": "Return to focus", "Trotzdem verlassen": "Leave anyway", "Belohnung freigeschaltet": "Reward unlocked", "Premium für 1 Tag": "Premium for 1 day", "Glückwunsch! Du hast über 100 Minuten fokussiert gearbeitet. Genieße alle Premium-Features.": "Congratulations! You focused for more than 100 minutes. Enjoy all Premium features.", "Scrollen, um den Prototyp zu steuern": "Scroll to control the prototype", "DISTRACTION": "DISTRACTION", "Basierend auf deinen Daten habe ich folgendes Muster erkannt:": "Based on your data, I identified the following pattern:", "Du verlierst deinen Fokus meistens zwischen 18:00 und 20:00 Uhr.": "You usually lose focus between 6:00 PM and 8:00 PM.", "Fokus-Niveau im Tagesverlauf": "Focus level throughout the day", "Deine erfolgreichsten Sitzungen dauern exakt": "Your most successful sessions last exactly", "Mein Tipp:": "My tip:", "Versuche kürzere Pausen nach intensiven Lernphasen einzuplanen und reduziere die Sitzungsdauer am Abend.": "Try scheduling shorter breaks after intense study periods and reduce session length in the evening."},ru:{"Intro": "Введение"}};let currentLanguage='de';function normalizeText(v){return v.replace(/\s+/g,' ').trim()}function translateNode(node,lang){if(node.nodeType!==Node.TEXT_NODE)return;const clean=normalizeText(node.nodeValue);if(!clean)return;if(!node.__deOriginal)node.__deOriginal=clean;const original=node.__deOriginal;const value=lang==='de'?original:(I18N[lang][original]||original);const lead=node.nodeValue.match(/^\s*/)[0],trail=node.nodeValue.match(/\s*$/)[0];node.nodeValue=lead+value+trail}function translateTree(root,lang){const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,{acceptNode(n){return ['SCRIPT','STYLE'].includes(n.parentElement?.tagName)?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}});const nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);nodes.forEach(n=>translateNode(n,lang));document.querySelectorAll('[title]').forEach(el=>{if(!el.dataset.deTitle)el.dataset.deTitle=el.title;el.title=lang==='de'?el.dataset.deTitle:(I18N[lang][el.dataset.deTitle]||el.dataset.deTitle)});document.querySelectorAll('[aria-label]').forEach(el=>{if(!el.dataset.deAriaLabel)el.dataset.deAriaLabel=el.getAttribute('aria-label');const orig=el.dataset.deAriaLabel;el.setAttribute('aria-label',lang==='de'?orig:(I18N[lang][orig]||orig))})}function setLanguage(lang,save=true){if(!['de','en'].includes(lang))lang='de';currentLanguage=lang;document.documentElement.lang=lang;translateTree(document.body,lang);const langCodeEl=document.getElementById('langCode');if(langCodeEl)langCodeEl.textContent=lang.toUpperCase();document.querySelectorAll('.lang-option').forEach(b=>b.classList.toggle('active',b.dataset.lang===lang));document.title='v17.4.1 Mission Generation Repair';if(save)window.FocusModeApp.services.storage.setText('focus-mode-language',lang);if(typeof window.refreshDataManagementUI==='function')window.refreshDataManagementUI();if(typeof window.renderFocusChoiceV116==='function')window.renderFocusChoiceV116();if(typeof window.refreshHomeStats==='function')window.refreshHomeStats();document.getElementById('langPicker')?.classList.remove('open');document.getElementById('langToggle')?.setAttribute('aria-expanded','false')}function detectLanguage(){const saved=window.FocusModeApp.services.storage.getText('focus-mode-language');if(saved)return saved;const langs=navigator.languages||[navigator.language||'de'];for(const item of langs){const code=item.toLowerCase().split('-')[0];if(['de','en'].includes(code))return code}return'en'}document.title='v17.4.1 Mission Generation Repair';document.addEventListener('DOMContentLoaded',()=>{const picker=document.getElementById('langPicker'),toggle=document.getElementById('langToggle');toggle.addEventListener('click',e=>{e.stopPropagation();picker.classList.toggle('open');toggle.setAttribute('aria-expanded',picker.classList.contains('open'))});document.querySelectorAll('.lang-option').forEach(b=>b.addEventListener('click',()=>setLanguage(b.dataset.lang)));document.addEventListener('click',()=>picker.classList.remove('open'));setLanguage(detectLanguage(),false);new MutationObserver(records=>{for(const record of records)for(const node of record.addedNodes){if(node.nodeType===Node.TEXT_NODE)translateNode(node,currentLanguage);else if(node.nodeType===Node.ELEMENT_NODE)translateTree(node,currentLanguage)}}).observe(document.body,{childList:true,subtree:true});lucide.createIcons()});

Object.assign(I18N.en,{"Lücke": "Product Gap", "Modi": "Modes", "Mission": "Mission", "Fokus": "Focus", "Anpassung": "Adaptation", "Fortschritt": "Progress", "Coach": "Coach", "Vision": "Vision", "Aus „Ich sollte anfangen“ wird echte Fokuszeit.": "Turn “I should start” into real focus.", "Focus Mode+ hilft dir, wichtige Aufgaben zu beginnen, digitale Ablenkungen zu blockieren und Schritt für Schritt dranzubleiben.": "Focus Mode+ helps you begin important tasks, block digital distractions, and keep moving forward one focused step at at a time.", "2 Fokusmodi": "2 focus modes", "1 klarer nächster Schritt": "1 clear next step", "0 unnötige Ablenkungen": "0 unnecessary distractions", "Das Problem ist nicht nur die Ablenkung.": "Distraction is only part of the problem.", "Viele Aufgaben scheitern schon vor der ersten Fokusminute: Das Ziel wirkt zu groß, der nächste Schritt ist unklar und das Smartphone bietet den einfacheren Ausweg.": "Many tasks fail before the first focused minute: the goal feels too large, the next step is unclear, and the smartphone offers an easier escape.", "Kein klarer Start": "No clear starting point", "Die Aufgabe bleibt abstrakt": "The task remains abstract", "Sofortige Ablenkung": "Instant distraction", "Der Feed ist nur einen Klick entfernt": "The feed is only one tap away", "03 / LÜCKE": "03 / PRODUCT GAP", "Ein Timer kennt dein Ziel nicht. Ein Plan schützt deinen Fokus nicht.": "A timer does not understand your goal. A plan does not protect your focus.", "Timer messen Zeit. App-Blocker sperren Anwendungen. Planungstools erstellen Listen. Focus Mode+ verbindet Ziel, nächsten Schritt, geschützte Ausführung und Anpassung in einem Ablauf.": "Timers measure time. App blockers restrict applications. Planning tools create lists. Focus Mode+ connects the goal, the next step, protected execution, and adaptation in one flow.", "Ziel statt nur Zeit": "Goals, not only time", "Ausführung statt nur Planung": "Execution, not only planning", "Anpassung statt statischer Liste": "Adaptation, not static lists", "04 / ZWEI MODI": "04 / TWO MODES", "Sofort fokussieren. Oder eine Mission verfolgen.": "Focus immediately. Or follow a mission.", "Nicht jede Aufgabe braucht Planung. Deshalb entscheidet der Nutzer selbst, wie viel Unterstützung gerade sinnvoll ist.": "Not every task requires a plan. Users decide how much support is useful in the current situation.", "Kurzer Fokus": "Quick Focus", "25 Minuten · Apps blockieren · direkt beginnen": "25 minutes · block distracting apps · start immediately", "Aufgabe strukturieren · Fokus-Schritte planen · Fortschritt anpassen": "Structure the task · plan focus steps · adapt progress", "Aus einer großen Aufgabe wird ein machbarer nächster Schritt.": "Turn a large task into one achievable next step.", "Der Nutzer beschreibt, was er schaffen möchte, fügt bei Bedarf Material hinzu und wählt den Kontext. Focus Mode+ erkennt Ziel und Frist, schätzt den Aufwand und erstellt realistische Fokus-Schritte.": "Users describe what they want to complete, optionally add relevant material, and select the context. Focus Mode+ identifies the goal and deadline, estimates the effort, and creates realistic focus steps.", "Prüfung": "Exam", "Aufgabe": "Task", "Projekt": "Project", "Eigene Mission": "Custom mission", "Planen. Fokussieren. Reflektieren. Anpassen.": "Plan. Focus. Reflect. Adapt.", "Eine Focus Mission begleitet die Aufgabe nicht nur bis zum Plan, sondern durch die tatsächliche Ausführung und den nächsten realistischen Schritt.": "A Focus Mission guides the task beyond planning, through actual execution and toward the next realistic step.", "Ziel verstehen": "Understand the goal", "Aufgabe, Material und Frist erfassen": "Capture the task, material, and deadline", "Nächsten Schritt wählen": "Choose the next step", "Eine realistische Sitzung statt eines überwältigenden Plans": "One realistic session instead of one overwhelming plan", "Geschützt arbeiten": "Work in a protected environment", "Ablenkende Apps blockieren": "Block distracting apps", "Ergebnis einschätzen": "Reflect on the result", "Verständnis und Sicherheit bewerten": "Assess understanding and confidence", "Mission anpassen": "Adapt the mission", "Dauer und nächste Schritte aktualisieren": "Update duration and next steps", "07 / GESCHÜTZTER FOKUS": "07 / PROTECTED FOCUS", "Der Plan zählt erst, wenn die Arbeit beginnt.": "A plan only matters when the work begins.", "Während der Sitzung schützt Focus Mode+ die gewählte Arbeitsumgebung. Beim Versuch, in eine Ablenkung zu wechseln, unterbricht eine bewusste Barriere den Automatismus.": "During the session, Focus Mode+ protects the selected working environment. When the user attempts to switch to a distraction, a conscious barrier interrupts the automatic impulse.", "Benötigte Werkzeuge bleiben verfügbar": "Required tools remain available", "Ablenkende Apps werden blockiert": "Distracting apps are blocked", "08 / ANPASSUNG": "08 / ADAPTATION", "Die Mission lernt aus jeder Sitzung.": "The mission learns from every session.", "Nach der Sitzung bewertet der Nutzer, wie sicher er sich mit dem Ergebnis fühlt. Focus Mode+ vergleicht Feedback und Planung, schätzt das persönliche Tempo neu und passt die nächste Sitzung an.": "After each session, users assess how confident they feel about the result. Focus Mode+ compares feedback with the original plan, reassesses the personal pace, and adapts the next session.", "Verständnis": "Understanding", "Minuten Praxis": "Practice minutes", "angepasster Schritt": "adapted step", "09 / FORTSCHRITT": "09 / PROGRESS", "Zeit zeigt deinen Einsatz. Missionen zeigen deinen Fortschritt.": "Time shows your effort. Missions show your progress.", "Fokuszeit bleibt eine reale persönliche Kennzahl. Mission-Fortschritt zeigt die Richtung. Die Plan-Serie belohnt den eigenen Rhythmus, nicht tägliche Aktivität um jeden Preis.": "Focus time remains a real personal metric. Mission progress shows direction. The Plan Streak rewards the user’s own rhythm, not daily activity at any cost.", "Plan-Serie": "Plan Streak", "Wochenliga": "Weekly League", "10 / LANGZEIT-COACHING": "10 / LONG-TERM COACHING", "Aus Fokusdaten werden bessere Routinen.": "Turn focus data into better routines.", "Während Focus Missions einzelne Aufgaben begleiten, erkennt der optionale AI Coach langfristige Muster: Wann sinkt die Konzentration? Welche Sitzungsdauer funktioniert? Welche Routine sollte angepasst werden?": "While Focus Missions guide individual tasks, the optional AI Coach identifies long-term patterns: When does concentration decrease? Which session length works best? Which routine should be adjusted?", "Erweiterte Langzeitstatistiken, Verhaltensanalyse und strengere Blockierungsmodi können Teil von Focus Mode+ Premium werden.": "Advanced long-term statistics, behavioral analysis, and stricter blocking modes may become part of Focus Mode+ Premium.", "AI Coach öffnen ↗": "Open AI Coach ↗", "11 / NEXT STEP": "11 / NEXT STEP", "Ein starker Prototyp. Jetzt braucht es echte Nutzung.": "A strong prototype. Now it needs real usage.", "Focus Mode+ ist aktuell ein interaktiver Concept Prototype. Der nächste Schritt ist nicht noch eine Funktion, sondern die Validierung mit echten Aufgaben und echten Nutzern.": "Focus Mode+ is currently an interactive concept prototype. The next step is not another feature, but validation with real tasks and real users.", "Verstehen Schüler den Mehrwert?": "Do students understand the value?", "Problem und Zielgruppe prüfen": "Test the problem and target group", "Kehren sie zurück?": "Do they return?", "Mehrere Sitzungen statt einmaliger Neugier": "Multiple sessions instead of one-time curiosity", "Verbessert der Ablauf die Ausführung?": "Does the flow improve execution?", "Planung und Schutz gemeinsam testen": "Test planning and protection together", "Langfristige Vision": "Long-term vision", "Ein Fokus-System für selbstständige Arbeit über Smartphone, Mac und PC.": "One focus system for independent work across smartphones, Macs, and PCs.", "Prototyp selbst testen": "Test the prototype", "Nach oben": "Back to top", "01 / INTRO": "01 / INTRO", "02 / PROBLEM": "02 / PROBLEM", "05 / FOCUS MISSION": "05 / FOCUS MISSION", "06 / WORKFLOW": "06 / WORKFLOW", "Konzept entdecken": "Explore the concept", "Prototyp testen": "Test the prototype", "Barriere anzeigen ↗": "Show the barrier ↗", "Trainiere deine Aufmerksamkeit. Nicht deine Ablenkung.": "Train your attention. Not your distraction.", "Daten & Backup": "Data & Backup", "Lokale Daten sichern, importieren oder zurücksetzen": "Export, import, or reset local data", "Lokale Datenstabilität": "Local Data Stability", "Übersicht deiner lokal gespeicherten Fokus-Daten.": "Overview of your locally stored focus data.", "Aktive Missionen": "Active Missions", "Gespeicherte Sitzungen": "Saved Sessions", "Aktive Sitzung": "Active Session", "Datenstatus": "Data Status", "Letztes Backup": "Last Backup", "Aktionen": "Actions", "Daten exportieren": "Export Data", "JSON-Backup herunterladen": "Download JSON backup", "Daten importieren": "Import Data", "Aus JSON-Datei wiederherstellen": "Restore from JSON file", "Letztes Backup wiederherstellen": "Restore Last Backup", "Vorherigen Zustand laden": "Load previous state", "Lokale Daten zurücksetzen": "Reset Local Data", "Missionen & Sitzungen löschen (Backup bleibt erhalten)": "Clear missions & sessions (keeps last backup)", "Import-Vorschau": "Import Preview", "Dies ersetzt die aktuellen lokalen App-Daten. Ein Backup der aktuellen Daten wird automatisch erstellt.": "This will replace local app data. A backup of the current data will be created automatically.", "Import bestätigen": "Confirm Import", "Abbrechen": "Cancel", "Lokale Daten wirklich zurücksetzen?": "Reset local data?", "Alle lokalen Missionen und Sitzungen werden gelöscht. Deine Spracheinstellung und das letzte Backup bleiben erhalten.": "All local missions and sessions will be cleared. Your language preference and last backup will be preserved.", "Jetzt zurücksetzen": "Reset Now", "Start": "Home", "Home": "Home", "Missionen": "Missions", "Verlauf": "History", "Profil": "Profile", "Hauptnavigation": "Main navigation", "Missionen verwalten": "Manage Missions", "Aktive, archivierte und primäre Missionen": "Active, archived and primary Missions", "2 aktive Missionen erreicht": "2 active Missions reached", "Deine Missionen": "Your Missions", "Aktiv": "Active", "Abgeschlossen": "Completed", "Archiv": "Archive", "Keine Missionen": "No Missions", "In diesem Bereich gibt es noch keine Mission.": "There are no missions in this section yet.", "Hauptmission": "Primary Mission", "HAUPTMISSION": "PRIMARY MISSION", "AKTIVE MISSION": "ACTIVE MISSION", "NÄCHSTER SCHRITT": "NEXT STEP", "Schritt starten": "Start step", "Was möchtest du jetzt erledigen?": "What would you like to get done now?", "HEUTE": "TODAY", "FOKUS": "FOCUS", "SITZUNGEN": "SESSIONS", "SITZUNG": "SESSION", "SERIE": "STREAK", "AKTIVITÄT": "ACTIVITY", "Alle anzeigen": "View all", "Noch keine Aktivität": "No activity yet", "Abgeschlossene und teilweise Fokus-Sitzungen erscheinen hier chronologisch.": "Completed and partial focus sessions appear here chronologically.", "Als Hauptmission setzen": "Set as Primary Mission", "Mission öffnen": "Open Mission", "Archivieren": "Archive", "Wieder aktivieren": "Reactivate", "Wieder öffnen": "Reopen", "Als abgeschlossen markieren": "Mark as completed", "Endgültig löschen": "Delete permanently", "Sitzungsverlauf": "Session History", "Deine Fokuszeit": "Your Focus Time", "Heute": "Today", "Alle Sitzungen": "All Sessions", "Sprache": "Language", "Oberflächensprache wählen": "Select interface language", "Was möchtest du fokussieren?": "What would you like to focus on?", "Kurzen Fokus starten": "Start Quick Focus", "Aufgabe und Dauer selbst festlegen": "Set your own task and duration", "Deine Focus Missions": "Your Focus Missions", "+ Neue Focus Mission": "+ New Focus Mission", "Schließen": "Close", "Statistiken": "Statistics", "Fokusschutz aktiv": "Focus Protection active", "Fokus-Schutz aktiv": "Focus Protection active", "Tippen zum Anpassen": "Tap to adjust", "Was lenkt dich ab?": "What distracts you?", "Fertig": "Done", "Auswahl speichern": "Done"}); window.FocusModeApp.services.storage.getText("focus-mode-language")==="ru"&&window.FocusModeApp.services.storage.setText("focus-mode-language","de");

/** Virtual module: src/core/legacy-cleanup-gate.js */
(function(g){
 'use strict';
 const A=g.FocusModeApp;
 if(!A?.core?.registerModule)throw new Error('Architecture Shell required');
 if(A.core.hasModule('core.legacyCleanupGate'))return;
 const candidates=Object.freeze([
  'legacyV10_startQuickFocus_1','legacyV10_prepareLearningSession_1','legacyV10_prepareLearningSession_2',
  'legacyV10_prepareLearningSession_3','legacyV10_completeLearningSession_1','legacyV10_completeLearningSession_2',
  'legacyV10_startFocusSession_1','legacyV10_stopFocusSession_1','legacyV10_currentUcSession_1',
  'legacyV10_showUcTask_1','legacyV10_startConfiguredQuickFocus_1','legacyUpdateRealWeekV81'
 ]);
 const requiredModules=Object.freeze(['repositories.sessions','core.runtimeOwnership','core.sessionRecovery','features.missionFlow']);
 const publicEntries=Object.freeze(['startSession','checkpointActiveSession','endSessionByUser','resumeRecoveredSession','confirmAIPlan','prepareLearningSession','showPlanUpdate','renderAIPlan']);
 function inspect(){
  const modules=requiredModules.map(name=>({name,available:A.core.hasModule(name)}));
  const entries=publicEntries.map(name=>({name,available:typeof g[name]==='function'}));
  const legacy=candidates.map(name=>({name,present:typeof g[name]==='function'}));
  const blockers=[];
  modules.filter(x=>!x.available).forEach(x=>blockers.push('missing_module:'+x.name));
  entries.filter(x=>!x.available).forEach(x=>blockers.push('missing_entry:'+x.name));
  return Object.freeze({version:'13.2.4',safeForPhysicalDeletion:blockers.length===0,modules,entries,legacy,blockers});
 }
 function assertReady(){const report=inspect();if(!report.safeForPhysicalDeletion)console.error('[LegacyCleanupGate]',{event:'cleanup_blocked',blockers:report.blockers});else console.info('[LegacyCleanupGate]',{event:'legacy_pruning_verified',remainingLegacyCandidates:report.legacy.filter(x=>x.present).length});return report}
 const gate=Object.freeze({version:'13.2.4',candidates,requiredModules,publicEntries,inspect,assertReady});
 A.core.legacyCleanupGate=A.core.registerModule('core.legacyCleanupGate',gate,{virtualPath:'src/core/legacy-cleanup-gate.js',version:'13.2.4',status:'post-pruning-audit'});
 A.version='v17.4.1 Mission Generation Repair';A.name='Home System';A.core.lifecycle.phase='home-system-ready';A.core.lifecycle.ready=true;
 A.compatibility.legacyCleanupGate=Object.freeze({version:'13.2.4',physicalDeletions:12,storageKeysRenamed:0,formatsChanged:0,uiChanged:false});
 document.addEventListener('DOMContentLoaded',()=>setTimeout(assertReady,0),{once:true});
})(window);

(function(g){
 'use strict';
 const A=g.FocusModeApp;
 if(!A?.core?.registerModule)throw new Error('Architecture Shell required');
 if(A.core.hasModule('core.architectureStabilization'))return;
 const requiredModules=Object.freeze(['services.storage','repositories.sessions','repositories.missions','core.runtimeOwnership','core.sessionRecovery','features.missionFlow']);
 const requiredStorageAPI=Object.freeze(['getText','setText','getJSON','setJSON','remove','has','backup']);
 const requiredEntries=Object.freeze(['setAppScreen','startSession','endSessionByUser','resumeRecoveredSession','confirmAIPlan','prepareLearningSession','showPlanUpdate','renderAIPlan']);
 function inspect(){
  const modules=requiredModules.map(name=>({name,available:A.core.hasModule(name)}));
  const storage=requiredStorageAPI.map(name=>({name,available:typeof A.services.storage?.[name]==='function'}));
  const entries=requiredEntries.map(name=>({name,available:typeof g[name]==='function'}));
  const blockers=[...modules.filter(x=>!x.available).map(x=>'module:'+x.name),...storage.filter(x=>!x.available).map(x=>'storage:'+x.name),...entries.filter(x=>!x.available).map(x=>'entry:'+x.name)];
  return Object.freeze({version:'17.3',stable:blockers.length===0,modules,storage,entries,blockers});
 }
 function assertStable(){const report=inspect();(report.stable?console.info:console.error)('[ArchitectureStabilization]',{event:report.stable?'architecture_stable':'architecture_blocked',blockers:report.blockers});return report}
 const api=Object.freeze({version:'17.3',inspect,assertStable});
 A.core.architectureStabilization=A.core.registerModule('core.architectureStabilization',api,{virtualPath:'src/core/architecture-stabilization.js',version:'17.3',status:'stable-baseline'});
 A.version='v17.4.1 Mission Generation Repair';A.name='Home System';A.core.lifecycle.phase='home-system-ready';A.core.lifecycle.ready=true;
 A.compatibility.architectureStabilization=Object.freeze({version:'17.3',storageRegressionFixed:true,storageKeysRenamed:0,formatsChanged:0,uiChanged:false});
 if(typeof g.installNavApplyHookV17==='function'){g.installNavApplyHookV17()}
 if(!A.core.hasModule('core.navigationController')&&typeof g.navigateToRoot==='function'){
  A.core.navigationController=A.core.registerModule('core.navigationController',Object.freeze({
   version:'17.3',
   navigateToRoot:g.navigateToRoot,
   navigateForward:g.navigateForward,
   navigateBack:g.navigateBack,
   replaceScreen:g.replaceScreen,
   showBottomNavigation:g.showBottomNavigation,
   hideBottomNavigation:g.hideBottomNavigation,
   syncBottomNavigationForScreen:g.syncBottomNavigationForScreen,
   getState:()=>g.__navigationStateV17
  }),{virtualPath:'src/core/navigation.js',version:'17.3',status:'active-controller'});
 }
 document.addEventListener('DOMContentLoaded',()=>{
  setTimeout(assertStable,0);
  if(typeof g.installNavApplyHookV17==='function')g.installNavApplyHookV17();
  if(typeof g.syncBottomNavigationForScreen==='function')g.syncBottomNavigationForScreen();
  setTimeout(()=>{if(typeof g.syncBottomNavigationForScreen==='function')g.syncBottomNavigationForScreen()},120);
 },{once:true});
})(window);

(function(g){
 'use strict';
 const A=g.FocusModeApp;
 if(typeof I18N==='object'&&I18N.en){
  Object.assign(I18N.en,{
   'Offline-Modus':'Offline Mode',
   'Lokale Funktionen bleiben verfügbar. AI-Funktionen benötigen eine Internetverbindung.':'Local features remain available. AI features require an internet connection.',
   'Keine Internetverbindung':'No internet connection',
   'Die AI-Mission kann erstellt werden, sobald du wieder online bist.':'Your AI Mission can be created when you are back online.',
   'Deine Eingaben bleiben erhalten.':'Your input has been preserved.',
   'Erneut versuchen':'Try Again',
   'Zurück':'Back',
   'Ohne Anpassung fortfahren':'Continue without Adaptation',
   'Plan mit AI anpassen':'Adapt Plan with AI',
   'KEINE INTERNETVERBINDUNG':'NO INTERNET CONNECTION',
   'ANPASSUNG NICHT VERFÜGBAR':'ADAPTATION UNAVAILABLE',
   'ERGEBNIS GESPEICHERT':'RESULT SAVED',
   'Keine Internetverbindung. Dein Fokus-Ergebnis wurde lokal gespeichert und dein bisheriger Plan bleibt unverändert.':'No internet connection. Your focus session result has been saved locally and your existing plan remains unchanged.',
   'Du kannst ohne Anpassung fortfahren oder es erneut versuchen, sobald du wieder online bist.':'You can continue without Adaptation or try again when you are back online.',
   'Zum Dashboard':'Back to Dashboard'
  });
 }
 function ensureLucideFallback(){
  if(g.lucide&&g.lucide.icons)return;
  g.lucide={
   __fallback:true,
   createIcons:function(){
    if(typeof document==='undefined')return;
    document.querySelectorAll('i[data-lucide]').forEach(el=>{
     const name=el.getAttribute('data-lucide')||'circle';
     const cls=el.getAttribute('class')||'';
     const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');
     svg.setAttribute('xmlns','http://www.w3.org/2000/svg');
     svg.setAttribute('viewBox','0 0 24 24');
     svg.setAttribute('fill','none');
     svg.setAttribute('stroke','currentColor');
     svg.setAttribute('stroke-width','2');
     svg.setAttribute('stroke-linecap','round');
     svg.setAttribute('stroke-linejoin','round');
     svg.setAttribute('data-lucide',name);
     svg.setAttribute('class',('lucide lucide-'+name+' '+cls).trim());
     svg.innerHTML='<circle cx="12" cy="12" r="9"></circle>';
     el.replaceWith(svg);
    });
   }
  };
 }
 ensureLucideFallback();
 function isEnLang(){
  return (typeof currentLanguage==='string'&&currentLanguage==='en')||document.documentElement.lang==='en';
 }
 function syncOfflineStatusBanner(){
  const banner=document.getElementById('offlineStatusBanner');
  const offline=(typeof navigator!=='undefined'&&navigator.onLine===false);
  document.documentElement.classList.toggle('fm-is-offline',offline);
  if(!banner)return;
  const en=isEnLang();
  const titleEl=document.getElementById('offlineBannerTitle');
  const subEl=document.getElementById('offlineBannerSub');
  if(titleEl){
   if(titleEl.firstChild)titleEl.firstChild.__deOriginal='Offline-Modus';
   titleEl.textContent=en?'Offline Mode':'Offline-Modus';
  }
  if(subEl){
   if(subEl.firstChild)subEl.firstChild.__deOriginal='Lokale Funktionen bleiben verfügbar. AI-Funktionen benötigen eine Internetverbindung.';
   subEl.textContent=en?'Local features remain available. AI features require an internet connection.':'Lokale Funktionen bleiben verfügbar. AI-Funktionen benötigen eine Internetverbindung.';
  }
  banner.classList.toggle('hidden',!offline);
 }
 g.syncOfflineStatusBanner=syncOfflineStatusBanner;
 if(typeof g.setLanguage==='function'&&!g.__fmSetLangWrappedV172){
  const origSetLang=g.setLanguage;
  g.setLanguage=function(lang,save){
   const r=origSetLang.apply(this,arguments);
   syncOfflineStatusBanner();
   if(document.getElementById('missionError')?.dataset?.offlineState==='1'){
    g.showMissionOfflineError?.();
   }
   document.title='v17.4.1 Mission Generation Repair';
   return r;
  };
  g.__fmSetLangWrappedV172=true;
 }
 if(!g.__fmOfflineEventsBoundV172){
  g.__fmOfflineEventsBoundV172=true;
  g.addEventListener('online',syncOfflineStatusBanner);
  g.addEventListener('offline',syncOfflineStatusBanner);
 }
 if(A){
  A.version='v17.4.1 Mission Generation Repair';
  A.name='Home System';
  if(A.core?.lifecycle){
   A.core.lifecycle.phase='home-system-ready';
   A.core.lifecycle.ready=true;
  }
 }
 document.addEventListener('DOMContentLoaded',()=>{
  document.title='v17.4.1 Mission Generation Repair';
  const badge=document.getElementById('dataAppVersionBadge');
  if(badge)badge.textContent='v17.4.1 Mission Generation Repair';
  ensureLucideFallback();
  g.lucide?.createIcons?.();
  syncOfflineStatusBanner();
  setTimeout(()=>{
   document.title='v17.4.1 Mission Generation Repair';
   syncOfflineStatusBanner();
  },150);
 });
})(window);
